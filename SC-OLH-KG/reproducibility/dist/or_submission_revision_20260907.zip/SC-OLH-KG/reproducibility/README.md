# Reproducing the current Operations Research manuscript

All commands below start at the repository or unpacked attachment root.
The current method is `profile_atlas_v2_method_spec.json`, read with
[`current_protocol_errata_20260907.md`](current_protocol_errata_20260907.md).
`paper_artifacts/or_review/final_evidence_registry_v1.json` identifies the 14
completed historical matrices; `paper_artifacts/submission_revision_20260907/`
contains the added matched-standardization and same-source portfolio comparisons.

## Environment

The experiment environment used Python 3.10.12. Package pins are in
`requirements-core.txt`, `requirements-botorch.txt` and
`requirements-transfer-overlays.txt` in this directory. Core statistical
reanalysis needs NumPy and SciPy; rendering also needs Matplotlib. Functional
SCBO runs need the BoTorch environment. Native transfer uses the separately
pinned official-method dependencies; GPy/Emukit and HyperBO use separate overlay
environments because their dependency requirements differ.

The proof toolchain is Lean 4.31.0 (`proof/lean-toolchain`). PDF builds require
LaTeX, BibTeX and `latexmk`; the INFORMS class and bibliography style are included.

```bash
export PYTHONPATH="$PWD/SC-OLH-KG${PYTHONPATH:+:$PYTHONPATH}"
```

## Compact per-cell evidence and statistical replay

The anonymous attachment includes `SC-OLH-KG/reproducibility/cells/*.jsonl`:
17,360 original experiment cells projected to analysis inputs. Each line has
`relative_result_path` and `cell`. Task IDs, seed IDs, arm, dimensions,
configuration, scalar outcomes, nested deployment truth and verifier counts,
oracle objective, costs and the reported failure are retained. The projection
omits policy/coefficient vectors, search histories and workstation metadata.
The synthetic revision's `rows.json` and Energy revision's `energy_rows.json`
are already small per-task records and are included directly. The reused
160-task diagnostic JSON is also included at the path named by the supplemental
protocol, so its original outcomes need not be recollected.

To run the existing statistical analyzers against the attachment, expand the
projected cells into the attachment's initially absent `results/` directory
(skip this step in a working repository where the original results exist):

```bash
python3 SC-OLH-KG/performance/export_submission_revision_bundle.py \
  --materialize-cells SC-OLH-KG/reproducibility/cells \
  --results-root SC-OLH-KG/results
```

Set the input root to those projected records, or to existing full local results:

```bash
export OR_RESULTS=SC-OLH-KG/results
export OR_ANALYSIS=SC-OLH-KG/reproducibility/replayed_analyses
mkdir -p "$OR_ANALYSIS"
```

Recompute the four profile matrices, preserving all task-level paired inputs:

```bash
python3 - <<'PY'
import json, os
from pathlib import Path
from performance.analyze_profile_stress_suite import analyze
root, out = Path(os.environ['OR_RESULTS']), Path(os.environ['OR_ANALYSIS'])
for name in ('primary', 'sensitivity', 'schema_descriptor', 'equal_preverification_cost'):
    paths = sorted((root / 'or_review_v2_evalpatch4' / ('profile_' + name)).rglob('cell*.json'))
    payload = analyze(paths)
    (out / ('profile_' + name + '.json')).write_text(json.dumps(payload, indent=2) + '\n')
    print(name, payload['status'], payload['row_count'])
PY
```

Pair synthetic arms by mechanism, latent-task seed, resolution and configuration.
The 160 latent tasks crossed with three resolutions are 480 correlated
resolution-task cells. Overall revision bootstrap resamples tasks within each
of the eight fixed mechanisms. For Energy, five algorithm seeds within a
market measure repeatability; geographic-region and market analyses preserve
that structure.

```bash
python3 SC-OLH-KG/performance/analyze_external_energy_v3.py \
  "$OR_RESULTS/or_review_energy_forecast_indexed_v3" \
  --expected-count 540 --out "$OR_ANALYSIS/energy_v3.json"
python3 SC-OLH-KG/performance/analyze_native_transfer_matrix.py \
  "$OR_RESULTS/or_review_native_transfer_official_d1000_n13_s80_99_v1" \
  --out "$OR_ANALYSIS/native_transfer.json"
python3 SC-OLH-KG/performance/analyze_functional_profile_scbo.py \
  --functional-root "$OR_RESULTS/or_review_functional_scbo_v2/primary" \
  --profile-root "$OR_RESULTS/or_review_v2_evalpatch4/profile_primary" \
  --out "$OR_ANALYSIS/functional_primary.json"
python3 SC-OLH-KG/performance/submission_revision_controls.py --analyze-only
python3 SC-OLH-KG/performance/submission_revision_energy.py --analyze-only
```

For functional rank sensitivity, use `rank_sensitivity` with the same primary
profile root. For functional equal-cost analysis, use
`equal_preverification_cost` and `profile_equal_preverification_cost` together;
its one algorithmic failure remains an unsuccessful primary outcome.
Energy V2 uses `analyze_external_energy_v2.py` on
`or_review_v1/energy_region_holdout` and `or_review_energy_functional_scbo_v2`.
V2 and V3 are distinct experiments and are never pooled.

Temporal JSONL records retain each certified policy's chronological-block,
nonoverlapping-window and sampled-distribution statistics in `temporal_audit`.
The mean/minimum and threshold counts can be recomputed from these fields;
`analyze_external_energy_temporal_audits.py:_summary` specifies the aggregations.
Their role is descriptive stability after the decision has been frozen.

## Re-executing the fixed synthetic matrices

Existing scalar evidence suffices for statistical replay. To generate fresh
simulation records under the historical fixed task definitions, use the
registered method freeze and evaluation commit labels:

```bash
python3 SC-OLH-KG/performance/run_profile_stress_matrix.py \
  --matrix primary --dimensions 200,1000,10000 --task-count 20 --workers 2 \
  --freeze-commit da8f1e5c594dace1cc667a2e4b87956b1001b67b \
  --evaluation-commit d514b61c98cb34cecf13e42ada1d262722a1def4 \
  --output-dir SC-OLH-KG/results/reproduction/profile_primary
```

For `sensitivity`, `schema_descriptor` and `equal_preverification_cost`, set
`--matrix` to that name and `--dimensions 1000`, and choose a separate output
directory. Expected counts are 2,880, 8,640, 1,280 and 800 respectively.
These identifiers reproduce task construction and record the historical
protocol; a rerun using revised source files is a new run.

The added comparison entrypoints fix their protocol before producing added
outcomes and reuse the existing source-method scalar records:

```bash
python3 SC-OLH-KG/performance/submission_revision_controls.py --workers 2
python3 SC-OLH-KG/performance/submission_revision_energy.py --workers 2
```

The functional runner is `run_functional_profile_scbo_matrix.py`; its exact
primary/rank/equal-cost settings and execution labels are in
`or_review_functional_profile_scbo_v2.json`. Native transfer is a separate
480-cell end-to-end comparison in `or_review_native_transfer_execution_v1.json`,
with `benchmark_transfer_fairness.py` and the official-method overlays. Its
13-call search and v69 80/128/128 verifier plus 8-call objective comparison are
different from the profile and Energy 80/80/80 binomial verifier.

## External Energy V3 data and execution

The data are Open Power System Data `time_series`, release `2020-10-06`,
DOI [10.25832/time_series/2020-10-06](https://doi.org/10.25832/time_series/2020-10-06).
The attachment includes the existing 5.6 MiB
`SC-OLH-KG/data/external/opsd_time_series_extended_v2.npz` and its preprocessing
manifest. It contains 21 markets for 2017–2019; V3 uses the 18 registered target
markets across five geographic regions. Reuse this local archive.

To recreate it when needed, pass the full market list. The four-market default
preprocessing command belongs to the older experiment:

```bash
python3 SC-OLH-KG/performance/prepare_opsd_energy_data.py \
  --source /path/to/time_series_60min_singleindex.csv \
  --markets AT,DE_LU,DK_1,DK_2,GB_GBN,IE_sem,IT_CNOR,IT_CSUD,IT_NORD,IT_SARD,IT_SICI,IT_SUD,NO_1,NO_2,NO_3,NO_4,NO_5,SE_1,SE_2,SE_3,SE_4 \
  --years 2017,2018,2019 --interpolation-limit 6 \
  --out SC-OLH-KG/data/external/opsd_time_series_extended_v2.npz
```

Omitting `--source` streams the pinned official CSV. The recorded existing
manifest gives the raw and compact file identities. The raw 130 MB CSV is not
part of the attachment. V3 uses forecast stress to define the 1,000-point
state-of-charge response profile and a separate 168-hour physical horizon.
Search, audit and verification periods are 2017, 2018 and 2019.

Run `run_external_energy_v3_matrix.py --phase designs` before `--phase targets`,
with the same `--data`, `--design-dir`, `--output-dir`, `--checkpoint-dir`,
`--method-freeze-commit` and `--execution-commit` arguments. Both commit labels
are `26e190552548abc7900d7145aa91e1cce604832d`; exact budgets and dimensions are
in `or_review_energy_forecast_indexed_v3.json`. There are 18 frozen designs and
540 target cells. `--workers 2` limits local parallelism. The source-scored
method uses 768 source calls per regional design, ten initialization and
thirteen total target search calls. Its completed result remains a negative
external control.

```bash
for phase in designs targets; do
  python3 SC-OLH-KG/performance/run_external_energy_v3_matrix.py \
    --phase "$phase" --workers 2 \
    --data SC-OLH-KG/data/external/opsd_time_series_extended_v2.npz \
    --design-dir SC-OLH-KG/results/reproduction_energy/designs \
    --output-dir SC-OLH-KG/results/reproduction_energy/targets \
    --checkpoint-dir SC-OLH-KG/checkpoints/reproduction_energy \
    --method-freeze-commit 26e190552548abc7900d7145aa91e1cce604832d \
    --execution-commit 26e190552548abc7900d7145aa91e1cce604832d
done
```

## Analyses, rendering, manuscript and proof

The dependency order is cell outcomes → task/market paired analysis → compact
analysis → table/figure renderer → LaTeX PDFs. The existing compact analyses
under `paper_artifacts/or_review/` preserve the original aggregate endpoints;
the separate revision artifacts add the corrected comparisons.

To compact any newly generated full analysis, use
`compact_or_review_analysis.py --analysis INPUT --out OUTPUT`. Write replayed
analyses to a separate directory; the historical frozen registry records the
original analyses. Current displays can be rendered directly from the included
compact evidence and revision analyses:

```bash
python3 SC-OLH-KG/performance/render_or_review_final_artifacts.py
latexmk -cd -pdf -interaction=nonstopmode -halt-on-error SC-OLH-KG/manuscript/main.tex
latexmk -cd -pdf -interaction=nonstopmode -halt-on-error SC-OLH-KG/manuscript/supplement.tex
(cd proof && lake --no-cache build SCOLHKG.PaperProofInterface)
```

The Lean target builds the current paper interface and its dependencies.
Source, initial target, adaptive target, verification, total and amortized
calls remain distinct. Calls per successful certification and call-count
amortization break-even are separately reported.

## Build the anonymous attachment

After the revised analyses and both PDFs are complete, run:

```bash
python3 SC-OLH-KG/performance/export_submission_revision_bundle.py
```

This writes `SC-OLH-KG/reproducibility/dist/or_submission_revision_20260907.zip`
from local files. It includes the current code dependency closure, registered
protocols and erratum, compact per-cell evidence, revision outcomes, compact
OPSD archive, manuscript sources/PDFs and Lean source/configuration. Its
`bundle_inventory.json` lists the files and per-matrix cell counts. The export
performs no upload.

## Limitations and historical records

Projected cells reproduce statistical inputs, not original raw-result bytes.
Historical hashes/receipts identify the original full records; raw-evidence
hash audits and policy-level temporal replay require those originals.
Search trajectories, policy vectors, model weights, checkpoints and the raw
OPSD CSV are excluded. The 17,360-record package preserves all historical
registered cells, including the reported algorithmic failure. Added comparisons
on existing tasks are post-review evidence, not a fresh independent seed cohort.

Older `paper_final_method_v1.json`, `paper_submission_experiment_registry_v1.json`,
`external_energy_reliability_v1.json` and positive Energy-confirmation results
remain historical. Current evidence does not use them as the paper's method,
registry or external-validity claim. Author, funding, cover-letter and journal
submission metadata are prepared separately by the authors.
