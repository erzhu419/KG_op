"""Acquisition functions."""

