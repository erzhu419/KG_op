# Source-scored structural initial designs

This directory contains the implementation and evidence for the current
Operations Research manuscript in `manuscript/main.tex`, with its electronic
companion in `manuscript/supplement.tex`.

The method selects ten profiles from an outcome-free library of 64 ordered
policies using replicated source safety and objective scores. The selected
profiles initialize a replaceable target optimizer; deployment uses an
independent frozen-shortlist verifier. The public representation describes
ordered policy-grid refinement, including `d=10000`.

## Current paper and evidence

- Method: `performance/manifests/profile_atlas_v2_method_spec.json`, read with
  `reproducibility/current_protocol_errata_20260907.md`.
- Synthetic protocol: `performance/manifests/profile_stress_v2_protocol.json`
  and `or_review_confirmatory_execution_v1.json`; the completed evaluation
  implementation is `or_review_profile_evaluation_patch_v4.json`.
- Completed evidence: `paper_artifacts/or_review/final_evidence_registry_v1.json`
  lists 14 matrices and 17,360 cells, including one reported functional-control
  algorithmic failure.
- September 2026 revision: `performance/manifests/submission_revision_controls_20260907.json`
  and `submission_revision_energy_20260907.json`, with per-task outcomes and
  paired analyses in `paper_artifacts/submission_revision_20260907/`.
- September 30 revision: `performance/manifests/submission_revision_20260930.json`
  and `paper_artifacts/submission_revision_20260930/`: mechanism attribution,
  240 new latent tasks from three new source-family/library seeds, and Energy V4.
- External application: Energy V4 gives every policy a common 50% initial
  inventory and reruns all 720 cells. It is a negative external control: the frozen source design certifies
  60/90 market-seed runs, compared with 70/90 for the original generic DCT control.
- Theory: `../proof/final_or_theory.md`; original checked paper interface:
  `../proof/SCOLHKG/PaperProofInterface.lean`.

The primary synthetic matrix contains 160 independently seeded latent tasks
in eight fixed mechanisms, each evaluated at three resolutions. The added
revision compares the frozen source design against a source-free design with
identical structural standardization and a simple greedy portfolio supplied
with the same source observations. These comparisons use existing tasks.
New confirmation gives 56/240 true certificates for source scoring versus
24/240 for standardized generic. Most of the effect comes from the source-selected
first center; the portfolio has better coverage and loss. The new design-stability
proposition has an analytic proof outside the original Lean interface.

The current reproduction guide is `reproducibility/README.md`. It covers
analysis from compact per-cell evidence, simulation entrypoints, the exact
Energy preprocessing parameters, figure/table rendering, PDF compilation and
the local anonymous attachment exporter.

## Build the manuscript

Run from the repository root:

```bash
python3 SC-OLH-KG/performance/render_submission_revision_20260930.py
latexmk -cd -pdf -interaction=nonstopmode -halt-on-error SC-OLH-KG/manuscript/main.tex
latexmk -cd -pdf -interaction=nonstopmode -halt-on-error SC-OLH-KG/manuscript/supplement.tex
```

Generated simulation output belongs under `results/`, `profiles/` or
`checkpoints/`. The compact submission attachment is written to
`reproducibility/dist/or_submission_revision_20260930.zip`.

## Historical implementations

The directory name preserves the project's SC-OLH-KG origin. Acquisition,
HVD, state-encoder, endpoint-replacement and earlier risk-objective-atlas
experiments remain historical implementations and ablations. In particular,
`paper_final_method_v1.json`, `paper_submission_experiment_registry_v1.json`,
`external_energy_reliability_v1.json` and their earlier positive Energy
confirmation describe preceding experiments. They are not the current paper's
method contract, experiment registry or external-validity conclusion.

Every current comparison reports source, initial target, adaptive target,
verification, total and amortized calls separately. Outcome-adjusted cost per
successful certification is a separate quantity from the call-count
amortization break-even.
