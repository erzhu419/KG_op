"""Variance decomposition models."""

