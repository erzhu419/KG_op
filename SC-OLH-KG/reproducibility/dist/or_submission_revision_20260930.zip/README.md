# Anonymous Operations Research supplementary code and data

Start with `SC-OLH-KG/reproducibility/README.md`. The article and electronic
companion are `SC-OLH-KG/manuscript/main.pdf` and `supplement.pdf`.

`reproducibility/cells/*.jsonl` contains one projected record per original
registered experiment cell (17,360 records, including the recorded failed
functional-control run). Each line stores `relative_result_path` and `cell`.
Projection retains task/seed/arm/configuration identifiers, every scalar
outcome, oracle objective, cost, nested deployment truth, verifier counts and
small profile identifiers. It omits policy vectors, coefficient vectors,
search histories and workstation runtime metadata. The added comparison's
per-task inputs and summaries are under `paper_artifacts/submission_revision_20260907`.
The September 30 revision is under `paper_artifacts/submission_revision_20260930`:
4,160 profile records include attribution, 240 prospective latent tasks crossed
with six arms, and library-size diagnostics; 720 Energy V4 records use common
50% initial inventory. Its five source archives and 18 designs are included.
The frozen local protocol is `performance/manifests/submission_revision_20260930.json`.

The source package contains the actual benchmark/analysis dependencies,
registered protocols and erratum, current compact evidence, manuscript sources
and PDFs, compact OPSD data and manifest, and Lean sources/configuration.
Full raw results, checkpoints, model weights, raw OPSD CSV, development notes,
private scheduler scripts and author-specific submission metadata are excluded.

The compact cells support fresh paired and cost analysis. They cannot reproduce
raw-result byte receipts or rerun a policy-level temporal audit; frozen original
receipts refer to the original files. Statistical temporal block summaries are
retained per cell. The current statistical commands and pairing units are in
the reproduction guide. Re-executing simulators or fitting third-party methods
requires the documented dependencies and compute time.

`paper_artifacts/hvd_diagnostic_summary.csv` contains the six aggregate inputs
needed by `performance/render_hvd_diagnostic.py`; historical seed-level HVD
records are outside this attachment. The added rank/design-stability proposition
has an analytic proof; the included Lean interface covers the original results.
